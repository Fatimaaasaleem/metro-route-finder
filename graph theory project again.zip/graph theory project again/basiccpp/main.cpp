#include <iostream>
using namespace std;
int main()
{
    int a[5], min;
    min = 0;
    for (int i = 0; i < 5; i++)
    {
        cout << "enter an integer: " << endl;
        cin >> a[i];
    }
    for (int i = 0; i < 5; i++)
    {
        cout << "the integers are :" << a[i] << endl;
    }
    for (int i = 0; i <= 5; i++)
    {
        if (a[i]<=min)
        {
           min=a[i];
        }
    }
    cout<<"the minimum value is: "<<min<<endl;

    return 0;
}