#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <unordered_map>
#include <queue>
#include <set>

using namespace std;

// Convert strings to lowercase
void toLowerCase(string &str) {
    transform(str.begin(), str.end(), str.begin(), ::tolower);
}

// Class for the entire metro network with line change detection
class MetroNetwork {
private:
    unordered_map<string, vector<string>> graph;
    unordered_map<string, set<string>> stationLines;  // station -> set of lines it belongs to

public:
    // Add connections for a line and track which line each station belongs to
    void addLine(const vector<string>& stations, const string& lineName) {
        for (int i = 0; i < stations.size(); i++) {
            string current = stations[i];
            toLowerCase(current);
            stationLines[current].insert(lineName);

            if (i > 0) {
                string prev = stations[i - 1];
                toLowerCase(prev);
                graph[current].push_back(prev);
                graph[prev].push_back(current);
            }

            if (i < stations.size() - 1) {
                string next = stations[i + 1];
                toLowerCase(next);
                graph[current].push_back(next);
                graph[next].push_back(current);
            }
        }
    }

    // Find and display route with line change notification
    void findRoute(const string& startStation, const string& endStation) {
        string start = startStation, end = endStation;
        toLowerCase(start);
        toLowerCase(end);

        if (graph.find(start) == graph.end() || graph.find(end) == graph.end()) {
            cout << "Start or end station not found in the metro network.\n";
            return;
        }

        queue<string> q;
        unordered_map<string, string> parent;
        set<string> visited;

        q.push(start);
        visited.insert(start);
        parent[start] = "";

        bool found = false;

        while (!q.empty()) {
            string current = q.front(); q.pop();

            if (current == end) {
                found = true;
                break;
            }

            for (const string& neighbor : graph[current]) {
                if (!visited.count(neighbor)) {
                    visited.insert(neighbor);
                    parent[neighbor] = current;
                    q.push(neighbor);
                }
            }
        }

        if (!found) {
            cout << "No route found between " << startStation << " and " << endStation << ".\n";
            return;
        }

        // Reconstruct the path
        vector<string> path;
        string step = end;
        while (step != "") {
            path.push_back(step);
            step = parent[step];
        }
        reverse(path.begin(), path.end());

        cout << "\nRoute from " << startStation << " to " << endStation << ":\n";

        // Display route with line change notifications
        string prevLine = "";
        for (int i = 0; i < path.size(); ++i) {
            string station = path[i];
            set<string> lines = stationLines[station];

            string currentLine;
            if (lines.size() == 1) {
                currentLine = *lines.begin();
            } else if (i < path.size() - 1) {
                // Choose the line shared with the next station
                set<string> nextLines = stationLines[path[i + 1]];
                for (const string& l : lines) {
                    if (nextLines.count(l)) {
                        currentLine = l;
                        break;
                    }
                }
            } else {
                currentLine = *lines.begin();  // fallback
            }

            // Notify on line change
            if (i == 0 || currentLine != prevLine) {
                cout << "\n>> Switch to **" << currentLine << "** line\n";
            }

            cout << i + 1 << ": " << station << "\n";
            prevLine = currentLine;
        }

        cout << "\nEstimated travel time: " << path.size() * 2 << " minutes\n";
    }
};

// Each metro line class
class redMetro {
public:
    vector<string> stations;
    redMetro() {
        stations = {"saddar", "marrir chowk", "liaquat bagh", "committee chowk", "waris khan", "chandni chowk", "rehmanabad",
                    "6th road", "shamsabad", "faizabad", "ijp", "potohar", "khayaban e johar", "faiz ahmed faiz", "kashmir highway", "chaman",
                    "ibn e sina", "katchehry", "pims", "stock exchange", "7th avenue", "shaheed millat", "parade ground", "pak scretariat"};
    }
};

class greenMetro {
public:
    vector<string> stations;
    greenMetro() {
        stations = {"pims", "sohan", "kuri road", "khanna pull", "gangal stop", "koral chowk", "gulberg"};
    }
};

class blueMetro {
public:
    vector<string> stations;
    blueMetro() {
        stations = {"pims", "cda headquarters", "aabpara", "mna hostel", "serena hotel", "lake view park", "bari imam", "malpur", "shadara", "dhok jilnal", "barakahu"};
    }
};

class orangeMetro {
public:
    vector<string> stations;
    orangeMetro() {
        stations = {"faiz ahmed faiz", "g-9", "high court", "police foundation", "nust", "golra mor", "gt road", "airport"};
    }
};

int main() {
    redMetro red;
    greenMetro green;
    blueMetro blue;
    orangeMetro orange;

    MetroNetwork network;

    // Add each line to the network with its name
    network.addLine(red.stations, "Red");
    network.addLine(green.stations, "Green");
    network.addLine(blue.stations, "Blue");
    network.addLine(orange.stations, "Orange");

    cout << "Welcome to the Metro Route Finder!\n";

    string start, end;
    cout << "\nEnter your starting station:\n";
    getline(cin, start);

    cout << "Enter your destination station:\n";
    getline(cin, end);

    network.findRoute(start, end);

    return 0;
}
